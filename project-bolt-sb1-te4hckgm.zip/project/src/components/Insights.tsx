import { useEffect, useState } from 'react';
import { supabase, Expense } from '../lib/supabase';
import {
  TrendingUp,
  TrendingDown,
  AlertCircle,
  Sparkles,
  DollarSign,
} from 'lucide-react';

interface Insight {
  type: 'positive' | 'negative' | 'neutral' | 'warning';
  title: string;
  description: string;
  icon: typeof TrendingUp;
}

export default function Insights() {
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [insights, setInsights] = useState<Insight[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchExpensesAndGenerateInsights();
  }, []);

  const fetchExpensesAndGenerateInsights = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('expenses')
      .select('*')
      .order('date', { ascending: false });

    if (!error && data) {
      setExpenses(data);
      generateInsights(data);
    }
    setLoading(false);
  };

  const generateInsights = (expenseData: Expense[]) => {
    const generatedInsights: Insight[] = [];
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();
    const lastMonth = currentMonth === 0 ? 11 : currentMonth - 1;
    const lastMonthYear = currentMonth === 0 ? currentYear - 1 : currentYear;

    const currentMonthExpenses = expenseData.filter((expense) => {
      const expenseDate = new Date(expense.date);
      return (
        expenseDate.getMonth() === currentMonth &&
        expenseDate.getFullYear() === currentYear
      );
    });

    const lastMonthExpenses = expenseData.filter((expense) => {
      const expenseDate = new Date(expense.date);
      return (
        expenseDate.getMonth() === lastMonth &&
        expenseDate.getFullYear() === lastMonthYear
      );
    });

    const currentTotal = currentMonthExpenses.reduce(
      (sum, expense) => sum + Number(expense.amount),
      0
    );
    const lastTotal = lastMonthExpenses.reduce(
      (sum, expense) => sum + Number(expense.amount),
      0
    );

    if (lastTotal > 0) {
      const percentageChange = ((currentTotal - lastTotal) / lastTotal) * 100;

      if (percentageChange > 10) {
        generatedInsights.push({
          type: 'warning',
          title: 'Spending Increased',
          description: `You spent ${Math.abs(percentageChange).toFixed(
            1
          )}% more this month compared to last month`,
          icon: TrendingUp,
        });
      } else if (percentageChange < -10) {
        generatedInsights.push({
          type: 'positive',
          title: 'Great Progress!',
          description: `You spent ${Math.abs(percentageChange).toFixed(
            1
          )}% less this month compared to last month`,
          icon: TrendingDown,
        });
      }
    }

    const categoryTotals = currentMonthExpenses.reduce((acc, expense) => {
      acc[expense.category] = (acc[expense.category] || 0) + Number(expense.amount);
      return acc;
    }, {} as Record<string, number>);

    const topCategory = Object.entries(categoryTotals).sort(
      ([, a], [, b]) => b - a
    )[0];

    if (topCategory) {
      const percentage = (topCategory[1] / currentTotal) * 100;
      generatedInsights.push({
        type: 'neutral',
        title: `Top Spending: ${topCategory[0]}`,
        description: `${topCategory[0]} accounts for ${percentage.toFixed(
          1
        )}% of your total spending this month`,
        icon: DollarSign,
      });
    }

    const lastMonthCategoryTotals = lastMonthExpenses.reduce((acc, expense) => {
      acc[expense.category] = (acc[expense.category] || 0) + Number(expense.amount);
      return acc;
    }, {} as Record<string, number>);

    Object.keys(categoryTotals).forEach((category) => {
      const currentAmount = categoryTotals[category];
      const lastAmount = lastMonthCategoryTotals[category] || 0;

      if (lastAmount > 0) {
        const categoryChange = ((currentAmount - lastAmount) / lastAmount) * 100;

        if (categoryChange > 30) {
          generatedInsights.push({
            type: 'warning',
            title: `${category} Expenses Up`,
            description: `Your ${category.toLowerCase()} expenses increased by ${Math.abs(
              categoryChange
            ).toFixed(1)}% this month`,
            icon: AlertCircle,
          });
        }
      }
    });

    const avgTransaction = currentTotal / currentMonthExpenses.length;
    if (avgTransaction > 0) {
      generatedInsights.push({
        type: 'neutral',
        title: 'Average Transaction',
        description: `Your average transaction this month is $${avgTransaction.toFixed(
          2
        )}`,
        icon: Sparkles,
      });
    }

    if (currentMonthExpenses.length > lastMonthExpenses.length) {
      const diff = currentMonthExpenses.length - lastMonthExpenses.length;
      generatedInsights.push({
        type: 'neutral',
        title: 'More Transactions',
        description: `You made ${diff} more transactions this month compared to last month`,
        icon: TrendingUp,
      });
    }

    setInsights(generatedInsights);
  };

  const getInsightStyles = (type: string) => {
    switch (type) {
      case 'positive':
        return {
          bg: 'bg-green-50',
          border: 'border-green-200',
          icon: 'text-green-600',
          title: 'text-green-800',
        };
      case 'negative':
        return {
          bg: 'bg-red-50',
          border: 'border-red-200',
          icon: 'text-red-600',
          title: 'text-red-800',
        };
      case 'warning':
        return {
          bg: 'bg-orange-50',
          border: 'border-orange-200',
          icon: 'text-orange-600',
          title: 'text-orange-800',
        };
      default:
        return {
          bg: 'bg-blue-50',
          border: 'border-blue-200',
          icon: 'text-blue-600',
          title: 'text-blue-800',
        };
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-gray-800">AI Insights</h2>
        <p className="text-gray-500 mt-1">
          Smart analysis of your spending patterns
        </p>
      </div>

      {insights.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {insights.map((insight, index) => {
            const Icon = insight.icon;
            const styles = getInsightStyles(insight.type);

            return (
              <div
                key={index}
                className={`${styles.bg} ${styles.border} border rounded-xl p-6 transition-all hover:shadow-md`}
              >
                <div className="flex items-start gap-4">
                  <div className={`${styles.icon} mt-1`}>
                    <Icon size={24} />
                  </div>
                  <div className="flex-1">
                    <h3 className={`${styles.title} font-semibold mb-2`}>
                      {insight.title}
                    </h3>
                    <p className="text-gray-600 text-sm">{insight.description}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="bg-white rounded-xl p-12 shadow-sm border border-gray-100 text-center">
          <div className="mx-auto w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
            <Sparkles className="text-gray-400" size={32} />
          </div>
          <h3 className="text-lg font-semibold text-gray-800 mb-2">
            No Insights Yet
          </h3>
          <p className="text-gray-500">
            Add more expenses to get AI-powered insights about your spending
          </p>
        </div>
      )}

      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">
          Spending Summary
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center p-4 bg-gray-50 rounded-lg">
            <p className="text-sm text-gray-500 mb-1">Total Expenses</p>
            <p className="text-2xl font-bold text-gray-800">{expenses.length}</p>
          </div>
          <div className="text-center p-4 bg-gray-50 rounded-lg">
            <p className="text-sm text-gray-500 mb-1">This Month</p>
            <p className="text-2xl font-bold text-gray-800">
              {
                expenses.filter((expense) => {
                  const expenseDate = new Date(expense.date);
                  const now = new Date();
                  return (
                    expenseDate.getMonth() === now.getMonth() &&
                    expenseDate.getFullYear() === now.getFullYear()
                  );
                }).length
              }
            </p>
          </div>
          <div className="text-center p-4 bg-gray-50 rounded-lg">
            <p className="text-sm text-gray-500 mb-1">Categories</p>
            <p className="text-2xl font-bold text-gray-800">
              {
                new Set(expenses.map((expense) => expense.category)).size
              }
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
