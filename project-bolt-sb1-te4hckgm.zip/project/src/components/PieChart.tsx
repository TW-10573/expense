interface PieChartProps {
  data: Record<string, number>;
  colors: Record<string, string>;
}

export default function PieChart({ data, colors }: PieChartProps) {
  const total = Object.values(data).reduce((sum, value) => sum + value, 0);

  let currentAngle = 0;
  const segments = Object.entries(data).map(([category, value]) => {
    const percentage = (value / total) * 100;
    const angle = (value / total) * 360;
    const startAngle = currentAngle;
    currentAngle += angle;

    return {
      category,
      value,
      percentage,
      startAngle,
      angle,
      color: colors[category] || '#6366f1',
    };
  });

  const createArc = (startAngle: number, endAngle: number) => {
    const start = polarToCartesian(100, 100, 80, endAngle);
    const end = polarToCartesian(100, 100, 80, startAngle);
    const largeArcFlag = endAngle - startAngle <= 180 ? '0' : '1';

    return [
      'M', 100, 100,
      'L', start.x, start.y,
      'A', 80, 80, 0, largeArcFlag, 0, end.x, end.y,
      'Z'
    ].join(' ');
  };

  const polarToCartesian = (centerX: number, centerY: number, radius: number, angleInDegrees: number) => {
    const angleInRadians = ((angleInDegrees - 90) * Math.PI) / 180;
    return {
      x: centerX + radius * Math.cos(angleInRadians),
      y: centerY + radius * Math.sin(angleInRadians),
    };
  };

  return (
    <div>
      <svg viewBox="0 0 200 200" className="w-full max-w-xs mx-auto">
        {segments.map((segment, index) => (
          <path
            key={index}
            d={createArc(segment.startAngle, segment.startAngle + segment.angle)}
            fill={segment.color}
            className="transition-opacity hover:opacity-80 cursor-pointer"
          />
        ))}
      </svg>

      <div className="mt-6 space-y-2">
        {segments.map((segment, index) => (
          <div key={index} className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div
                className="w-3 h-3 rounded-full"
                style={{ backgroundColor: segment.color }}
              ></div>
              <span className="text-sm text-gray-600">{segment.category}</span>
            </div>
            <div className="text-right">
              <span className="text-sm font-semibold text-gray-800">
                ${segment.value.toFixed(2)}
              </span>
              <span className="text-xs text-gray-500 ml-2">
                ({segment.percentage.toFixed(1)}%)
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
