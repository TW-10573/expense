import { useState, DragEvent } from 'react';
import { Upload as UploadIcon, X, CheckCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';

export default function Upload() {
  const [isDragging, setIsDragging] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [extractedData, setExtractedData] = useState<{
    amount: string;
    date: string;
    shop_name: string;
    category: string;
  } | null>(null);

  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      handleFile(files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      handleFile(e.target.files[0]);
    }
  };

  const handleFile = (file: File) => {
    if (file.type.startsWith('image/')) {
      simulateScanning();
    }
  };

  const simulateScanning = () => {
    setIsScanning(true);
    setExtractedData(null);

    setTimeout(() => {
      const mockData = {
        amount: (Math.random() * 100 + 10).toFixed(2),
        date: new Date().toISOString().split('T')[0],
        shop_name: ['Whole Foods', 'Target', 'Starbucks', 'Amazon', 'Uber'][
          Math.floor(Math.random() * 5)
        ],
        category: ['Food', 'Travel', 'Shopping', 'Others'][
          Math.floor(Math.random() * 4)
        ],
      };
      setExtractedData(mockData);
      setIsScanning(false);
    }, 2000);
  };

  const handleSave = async () => {
    if (!extractedData) return;

    const { error } = await supabase.from('expenses').insert([
      {
        amount: parseFloat(extractedData.amount),
        date: extractedData.date,
        shop_name: extractedData.shop_name,
        category: extractedData.category,
        notes: '',
      },
    ]);

    if (!error) {
      setShowSuccess(true);
      setTimeout(() => {
        setShowSuccess(false);
        setExtractedData(null);
      }, 2000);
    }
  };

  const handleClear = () => {
    setExtractedData(null);
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-gray-800">Upload Receipt</h2>
        <p className="text-gray-500 mt-1">
          Upload a receipt image to automatically extract expense details
        </p>
      </div>

      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`bg-white rounded-xl p-12 shadow-sm border-2 border-dashed transition-all ${
          isDragging
            ? 'border-blue-500 bg-blue-50'
            : 'border-gray-300 hover:border-gray-400'
        }`}
      >
        <div className="text-center">
          <div className="mx-auto w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center mb-4">
            <UploadIcon className="text-blue-600" size={32} />
          </div>
          <h3 className="text-lg font-semibold text-gray-800 mb-2">
            Drop your receipt here
          </h3>
          <p className="text-gray-500 mb-6">or click to browse</p>
          <input
            type="file"
            accept="image/*"
            onChange={handleFileInput}
            className="hidden"
            id="file-upload"
          />
          <label
            htmlFor="file-upload"
            className="inline-block px-6 py-3 bg-blue-600 text-white rounded-lg font-medium cursor-pointer hover:bg-blue-700 transition-colors"
          >
            Select Image
          </label>
        </div>
      </div>

      {isScanning && (
        <div className="bg-white rounded-xl p-8 shadow-sm border border-gray-100">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p className="text-gray-600 font-medium">Scanning receipt...</p>
            <p className="text-sm text-gray-400 mt-2">
              AI is extracting expense details
            </p>
          </div>
        </div>
      )}

      {extractedData && !isScanning && (
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-800">
              Extracted Details
            </h3>
            <button
              onClick={handleClear}
              className="text-gray-400 hover:text-gray-600"
            >
              <X size={20} />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div>
              <label className="block text-sm text-gray-500 mb-1">Amount</label>
              <input
                type="text"
                value={extractedData.amount}
                onChange={(e) =>
                  setExtractedData({ ...extractedData, amount: e.target.value })
                }
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm text-gray-500 mb-1">Date</label>
              <input
                type="date"
                value={extractedData.date}
                onChange={(e) =>
                  setExtractedData({ ...extractedData, date: e.target.value })
                }
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm text-gray-500 mb-1">
                Shop Name
              </label>
              <input
                type="text"
                value={extractedData.shop_name}
                onChange={(e) =>
                  setExtractedData({
                    ...extractedData,
                    shop_name: e.target.value,
                  })
                }
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm text-gray-500 mb-1">Category</label>
              <select
                value={extractedData.category}
                onChange={(e) =>
                  setExtractedData({ ...extractedData, category: e.target.value })
                }
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="Food">Food</option>
                <option value="Travel">Travel</option>
                <option value="Shopping">Shopping</option>
                <option value="Others">Others</option>
              </select>
            </div>
          </div>

          <button
            onClick={handleSave}
            className="w-full py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors"
          >
            Save Expense
          </button>
        </div>
      )}

      {showSuccess && (
        <div className="fixed bottom-6 right-6 bg-green-500 text-white px-6 py-4 rounded-lg shadow-lg flex items-center gap-3 animate-slide-up">
          <CheckCircle size={24} />
          <span className="font-medium">Expense saved successfully!</span>
        </div>
      )}
    </div>
  );
}
