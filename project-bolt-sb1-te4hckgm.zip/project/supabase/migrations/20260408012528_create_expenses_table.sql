/*
  # Create Expenses Table for AI Smart Expense Tracker

  1. New Tables
    - `expenses`
      - `id` (uuid, primary key) - Unique identifier for each expense
      - `user_id` (uuid) - Reference to auth.users (for future auth integration)
      - `amount` (decimal) - Expense amount
      - `category` (text) - Category of expense (Food, Travel, Shopping, Others)
      - `shop_name` (text) - Name of the shop/merchant
      - `notes` (text) - Additional notes
      - `date` (date) - Date of the expense
      - `receipt_url` (text) - URL to the uploaded receipt image (optional)
      - `created_at` (timestamptz) - Timestamp when record was created
      - `updated_at` (timestamptz) - Timestamp when record was last updated

  2. Security
    - Enable RLS on `expenses` table
    - Add policies for public access (for demo purposes, can be restricted later)
*/

CREATE TABLE IF NOT EXISTS expenses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid,
  amount decimal(10, 2) NOT NULL,
  category text NOT NULL,
  shop_name text NOT NULL,
  notes text DEFAULT '',
  date date NOT NULL,
  receipt_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE expenses ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public read access to expenses"
  ON expenses
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Allow public insert access to expenses"
  ON expenses
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Allow public update access to expenses"
  ON expenses
  FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow public delete access to expenses"
  ON expenses
  FOR DELETE
  TO public
  USING (true);

CREATE INDEX IF NOT EXISTS idx_expenses_date ON expenses(date DESC);
CREATE INDEX IF NOT EXISTS idx_expenses_category ON expenses(category);